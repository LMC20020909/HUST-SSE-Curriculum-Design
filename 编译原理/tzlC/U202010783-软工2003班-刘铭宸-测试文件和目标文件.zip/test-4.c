int main() {
  int a = 10;
  switch(a) {
    case a: write(1);break;
  }
  return 0;
}